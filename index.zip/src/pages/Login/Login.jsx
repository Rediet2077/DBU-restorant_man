import React, { useState } from "react";
import "./Login.css";
import { useNavigate } from "react-router-dom";

// Define the required admin user object
const ADMIN_USER = { 
    username: "admin", 
    password: "admin", 
    balance: 9999.00, 
    role: "admin" 
};

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  // Function to ensure the admin user exists in localStorage (Good to keep for now)
  const checkAndCreateAdmin = (users) => {
    const adminExists = users.some(u => u.username === ADMIN_USER.username);
    
    if (!adminExists) {
        console.log("Admin user missing. Adding default admin data to localStorage.");
        users.push(ADMIN_USER);
        localStorage.setItem("users", JSON.stringify(users));
        return users;
    }
    return users;
  };

  const handleLogin = () => {
    let users = JSON.parse(localStorage.getItem("users")) || [];
    users = checkAndCreateAdmin(users);

    // Login.js (Inside handleLogin)

// This line searches for a perfect match in localStorage:
const user = users.find((u) => u.username === username && u.password === password);

// If user is found, it navigates:
if (user) {
    sessionStorage.setItem("currentUser", JSON.stringify(user));
    
    if (user.role === "admin") {
        navigate("/admindashboard"); 
    } else {
        // This is where user1 should be sent:
        navigate("/UserDashboard"); 
    }
} else {
    // This is the error you are seeing if the data doesn't match!
    alert("Invalid username or password! Please check your data."); 
}};

  return (
    <div className="login-container">
      <h2>Login</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
      <p>
        New user? <span className="auth-link" onClick={() => navigate("/register")}>Register here</span>
      </p>
    </div>
  );
}

export default Login;