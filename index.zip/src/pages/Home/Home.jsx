// src/pages/Home/Home.jsx
import React from "react";
import { Link } from "react-router-dom";
import "./Home.css";

import food1 from "../../assets/images/fulll.jpg";
import food2 from "../../assets/images/koker.jpg";
import food3 from "../../assets/images/picfood.jpg";
import heroImg from "../../assets/images/picdescktop.jpg";

const Home = () => {
  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero" id="home">
        <div className="hero-content">
          <div className="text-section">
            <h1>
              Enjoy Our <span>Delicious</span> Meal
            </h1>
            <p>
              DBU Launch delivers premium quality food right to your doorstep.
              Fast, fresh, and flavorful meals for students and staff at Debre
              Brehan University.
            </p>
            <Link to="/service">
              <button className="primary-btn">Order Now</button>
            </Link>
          </div>
          <div className="hero-img">
            <img src={heroImg} alt="Delicious Food" />
          </div>
        </div>
      </section>

      {/* Welcome Section */}
      <section className="welcome-section" id="about">
        <div className="welcome-content">
          <div className="welcome-text">
            <h3>We are ready to serve you with our premium delivery system</h3>
            <p>
              Located in the heart of Debre Brehan University, we provide
              high-quality meals prepared with fresh ingredients by our master
              chefs. Our mission is to deliver delicious, nutritious food
              quickly and efficiently to the university community.
            </p>
          </div>
          <div className="stats-container">
            <div className="stat-box">
              <h3>10+</h3>
              <p>Years Experience</p>
            </div>
            <div className="stat-box">
              <h3>5</h3>
              <p>Master Chefs</p>
            </div>
            <div className="stat-box">
              <h3>20+</h3>
              <p>Menu Items</p>
            </div>
          </div>
        </div>
      </section>

      {/* Food Section */}
      <section className="food-section" id="menu">
        <h2 className="section-title">Our Popular Dishes</h2>
        <div className="food-grid">
          <div className="food-card">
            <img src={food1} alt="Traditional Ful" />
            <h3>Traditional Ful</h3>
            <p>
              Flavorful Ethiopian ful medames with spices and herbs, served with
              fresh bread.
            </p>
          </div>

          <div className="food-card">
            <img src={food2} alt="Kokor" />
            <h3>Kokor</h3>
            <p>
              Crispy Ethiopian traditional kokor with our special sauce and
              spices.
            </p>
          </div>

          <div className="food-card">
            <img src={food3} alt="Enkulal Firfir" />
            <h3>Enkulal Firfir</h3>
            <p>
              Scrambled eggs with traditional spices and injera, perfect for
              breakfast.
            </p>
          </div>
        </div>

        {/* This button takes users to the Order Page */}
        <Link to="/service">
          <button className="primary-btn">More Menu Items →</button>
        </Link>
      </section>
    </div>
  );
};

export default Home;
