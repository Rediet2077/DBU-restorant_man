import React, { useState } from "react";
import "./Register.css";
import { useNavigate } from "react-router-dom";

function Register() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [balance, setBalance] = useState("");
  const navigate = useNavigate();

  const handleRegister = () => {
    if (!username || !password || !balance) {
      alert("Fill all fields correctly!");
      return;
    }

    const users = JSON.parse(localStorage.getItem("users")) || [];
    if (users.some((u) => u.username === username)) {
      alert("Username already exists!");
      return;
    }

    users.push({ username, password, balance: parseFloat(balance) });
    localStorage.setItem("users", JSON.stringify(users));

    alert("Registration successful!");
    navigate("/login");
  };

  return (
    <div className="register-container">
      <h2>Register</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
    <label htmlFor="idNumber">ID Number</label>
            <input type="text" id="idNumber" name="idNumber" required />

            {/* Phone */}
            <label htmlFor="phone">Phone Number (Ethiopia)</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              pattern="^(\+251|0)[1-9][0-9]{8}$"
              placeholder="e.g. +251912345678 or 0912345678"
              required
            />

            {/* Amount */}
            <label htmlFor="contractAmount">Contract Amount (ETB)</label>
            <input type="number" id="contractAmount" name="contractAmount" required />

      <button onClick={handleRegister}>Register</button>
      <p>
        Already have an account?{" "}
        <span onClick={() => navigate("/login")}>Login here</span>
      </p>
    </div>
  );
}

export default Register;
