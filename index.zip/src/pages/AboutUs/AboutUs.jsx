import React, { useEffect, useState } from "react";
import "./AboutUs.css";

import diningHall from "../../assets/images/image copy 2.png";
import sustainable from "../../assets/images/image copy.png";
import chef from "../../assets/images/image.png";


const AboutUs = () => {
  const testimonials = [
    {
      quote: "The digital lunch system made ordering meals so easy and fast!",
      author: "Bizuayehu, Computer Science Student",
    },
    {
      quote:
        "I can pay online without worrying about losing cash — it's very convenient!",
      author: "Amina, Engineering Student",
    },
    {
      quote:
        "This system is efficient and helps the cafeteria manage food better.",
      author: "Tewodros, IT Student",
    },
  ];

  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  return (
    <div className="about-container">
      {/* Hero Section */}
      <section
        className="hero-section"
        style={{ backgroundImage: `url(${diningHall})` }}
      >
        <h1>Nourishing Minds, Building Community</h1>
        <div className="mission-vision">
          <div>
            <h3>Our Mission</h3>
            <p>
              To develop a secure and efficient web-based lunch management
              system that digitalizes food ordering and payment processes,
              reduces manual errors, and improves the efficiency of lunch
              distribution for students and staff.
            </p>
          </div>
          <div>
            <h3>Our Vision</h3>
            <p>
              To be a leading example of digital transformation in university
              dining through innovation, sustainability, and student-centered
              service excellence.
            </p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <h2 className="section-title">Why Choose Our System</h2>
      <div className="features-grid">
        <div className="feature-card">
          <div className="feature-icon">🍴</div>
          <h3>Diverse Menus</h3>
          <p>
            Offers a variety of traditional Ethiopian dishes and healthy meal
            options for students and staff.
          </p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">💳</div>
          <h3>Online Payment</h3>
          <p>
            Secure digital payment system that minimizes cash handling and
            reduces human errors.
          </p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">⚙️</div>
          <h3>Efficient Management</h3>
          <p>
            Automated record tracking and data analytics for better meal
            planning and resource utilization.
          </p>
        </div>
      </div>

      {/* Sustainability Section */}
      <section className="sustainability-section">
        <div>
          <h2 className="section-title">Green Dining Initiative</h2>
          <ul>
            <li>Partnerships with local farmers</li>
            <li>Composting program</li>
            <li>Reusable container system</li>
            <li>Zero food waste commitment</li>
          </ul>
        </div>
        <div>
          <img src={sustainable} alt="Sustainable Practices" />
        </div>
      </section>

      {/* Team Section */}
      {/* <h2 className="section-title">Our Food Leadership</h2>
      <div className="team-grid">
        <div className="team-member">
          <img src={chef} alt="Head Chef" className="team-photo" />
          <h4>Chef Alemayehu</h4>
          <p>Head of Culinary Operations</p>
        </div>
        <div className="team-member">
          <img src={nutritionist} alt="Nutritionist" className="team-photo" />
          <h4>Dr. Selam</h4>
          <p>Chief Nutrition Expert</p>
        </div>
      </div> */}

      {/* Testimonials */}
      <section className="testimonial-section">
        <h2>What Our Students Say</h2>
        <div className="testimonial">
          <blockquote>{testimonials[index].quote}</blockquote>
          <p>- {testimonials[index].author}</p>
        </div>
        <a href="/ContactUs" className="cta-button">
          Contact Us
        </a>
      </section>
    </div>
  );
};

export default AboutUs;
