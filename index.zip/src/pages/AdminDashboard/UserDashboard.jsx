import React, { useEffect, useState, useCallback } from "react";
import "./AdminDashboard.css"; // Using the same styles for simplicity
import { useNavigate } from "react-router-dom";

function UserDashboard() {
  const [currentUser, setCurrentUser] = useState(null);
  const [userOrders, setUserOrders] = useState([]);
  const navigate = useNavigate();

  // --- Data Fetching and Security Check ---
  const fetchData = useCallback(() => {
    const user = JSON.parse(sessionStorage.getItem("currentUser"));
    
    // 🛑 SECURITY FIX: If no user or user is an admin, redirect to LOGIN
    if (!user || user.role === "admin") {
      alert("Access Denied. Logging out.");
      sessionStorage.removeItem("currentUser");
      // CRITICAL FIX: Redirect to the LOGIN page, not the dashboard itself!
      navigate("/login"); 
      return;
    } 
    setCurrentUser(user);

    // Fetch all orders and filter them for the current user
    const allOrders = JSON.parse(localStorage.getItem("orders")) || [];
    const orders = allOrders.filter(o => o.username === user.username);
    setUserOrders(orders);

  }, [navigate]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleLogout = () => {
    sessionStorage.removeItem("currentUser");
    navigate("/login");
  };

  if (!currentUser) {
    return <div className="loading">Loading Dashboard...</div>;
  }

  return (
    <div className="dashboard user-dashboard">
      <header>
        <h1>User Dashboard</h1>
        <button onClick={handleLogout}>Logout</button>
      </header>

      <div className="container">
        <h2>Welcome, {currentUser.username} (Customer)</h2>
        
        <div className="user-info">
            <p><strong>Current Balance:</strong> {currentUser.balance.toFixed(2)} ETB</p>
        </div>
        
        {/* --- Order History Section --- */}
        <div className="admin-section">
          <h3>📦 Your Order History ({userOrders.length})</h3>
          <div className="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Item</th>
                  <th>Price (ETB)</th>
                  <th>Payment Method</th>
                </tr>
              </thead>
              <tbody>
                {/* Display the user's orders */}
                {userOrders.map((o, i) => (
                  <tr key={i}>
                    <td>{o.date || 'N/A'}</td>
                    <td>{o.item}</td>
                    <td>{o.price ? o.price.toFixed(2) : 'N/A'}</td>
                    <td>{o.paymentMethod}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* --- Placeholder for Placing New Order --- */}
        <div className="admin-section">
            <h3>🛒 Place New Order</h3>
            <p>Order form goes here...</p>
        </div>
      </div>
    </div>
  );
}

export default UserDashboard;