import React, { useEffect, useState, useCallback } from "react";
import "./AdminDashboard.css";
import { useNavigate } from "react-router-dom";

// Hardcoded sample data to initialize localStorage if empty
const initialUsers = [
  // 🟢 FIX: Ensure both admin and customer are defined as objects in the array
  { username: "user1", password: "123", role: "customer" }, 
  { username: "admin", password: "admin", role: "admin" }, 
];
const initialOrders = [
  { id: 1, username: "user1", item: "Rice", price: 100, paymentMethod: "Cash", date: "2025-11-05" },
  { id: 2, username: "user2", item: "Pasta", price: 80, paymentMethod: "Card", date: "2025-11-05" },
];

function AdminDashboard() {
  const [currentUser, setCurrentUser] = useState(null);
  const [allUsers, setAllUsers] = useState([]);
  const [allOrders, setAllOrders] = useState([]);
  const navigate = useNavigate();

  // --- Data Fetching and Security Check ---
  const fetchData = useCallback(() => {
    const user = JSON.parse(sessionStorage.getItem("currentUser"));
    if (!user || user.role !== "admin") {
      sessionStorage.removeItem("currentUser");
      navigate("/login");
      return;
    } 
    setCurrentUser(user);

    // Initialize/Fetch Users
    let storedUsers = JSON.parse(localStorage.getItem("users"));
    // 🟢 Now this logic uses the corrected initialUsers array
    if (!storedUsers || storedUsers.length === 0) {
        localStorage.setItem("users", JSON.stringify(initialUsers));
        storedUsers = initialUsers;
    }
    setAllUsers(storedUsers);

    // Initialize/Fetch Orders
    let storedOrders = JSON.parse(localStorage.getItem("orders"));
    if (!storedOrders) {
        localStorage.setItem("orders", JSON.stringify(initialOrders));
        storedOrders = initialOrders;
    }
    setAllOrders(storedOrders);

  }, [navigate]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleLogout = () => {
    sessionStorage.removeItem("currentUser");
    navigate("/login");
  };

  const handleUpdateBalance = (username) => {
    const newBalanceStr = prompt(`Enter new balance for ${username} (ETB):`);
    const newBalance = parseFloat(newBalanceStr);

    if (isNaN(newBalance) || newBalance < 0) {
      alert("Invalid balance entered.");
      return;
    }

    const updatedUsers = allUsers.map(user => 
      user.username === username 
        ? { ...user, balance: newBalance } 
        : user
    );

    setAllUsers(updatedUsers);
    localStorage.setItem("users", JSON.stringify(updatedUsers));
  };

  const handleDeleteOrder = (orderId) => {
    if (window.confirm(`Are you sure you want to delete order ID: ${orderId}?`)) {
      const updatedOrders = allOrders.filter((o) => o.id !== orderId);
      setAllOrders(updatedOrders);
      localStorage.setItem("orders", JSON.stringify(updatedOrders));
      alert("Order deleted.");
    }
  };
  // --------------------------------------------------------------------------

  if (!currentUser) {
    return <div className="loading">Checking Admin Access...</div>;
  }

  return (
    <div className="dashboard admin-dashboard">
      <header>
        <h1>Admin Panel - DBU Launch</h1>
        <button onClick={handleLogout}>Logout</button>
      </header>

      <div className="container">
        <h2>Welcome, {currentUser.username} (Administrator)</h2>
        
        {/* --- 1. User Management Section --- */}
        <div className="admin-section">
          <h3>👤 All Customer Balances</h3>
          <div className="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>Username</th>
                  <th>Role</th>
                  <th>Balance (ETB)</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {/* Loop and display all customer users */}
                {allUsers
                  .filter(u => u.role === "customer") 
                  .map((user, i) => (
                    <tr key={i}>
                      <td>{user.username}</td>
                      <td>{user.role}</td>
                      <td>{user.balance ? user.balance.toFixed(2) : '0.00'}</td>
                      <td>
                        <button 
                          className="action-btn update-btn" 
                          onClick={() => handleUpdateBalance(user.username)}
                        >
                          Update Balance
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* --- 2. All Orders Section --- */}
        <div className="admin-section">
          <h3>📦 All Placed Orders ({allOrders.length})</h3>
          <div className="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>User</th>
                  <th>Item</th>
                  <th>Price (ETB)</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {/* Loop and display all orders */}
                {allOrders.map((o) => (
                  <tr key={o.id}>
                    <td>{o.id}</td>
                    <td>{o.username}</td>
                    <td>{o.item}</td>
                    <td>{o.price ? o.price.toFixed(2) : 'N/A'}</td>
                    <td>
                      <button 
                        className="action-btn delete-btn" 
                        onClick={() => handleDeleteOrder(o.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;