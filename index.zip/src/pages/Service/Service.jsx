import React, { useState } from "react";
import { Link } from "react-router-dom"; 
import "./Service.css";

// Images
import foodImage from "../../assets/images/food.png";
import contractImage from "../../assets/images/OIP.jpg";
import feedbackImage from "../../assets/images/feedbackk.jpg";

const Service = () => {
  const [showContract, setShowContract] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackSuccess, setFeedbackSuccess] = useState(false);
  const [contractSuccess, setContractSuccess] = useState(false);

  // Show main menu
  const showMainMenu = () => {
    setShowContract(false);
    setShowFeedback(false);
    setFeedbackSuccess(false);
    setContractSuccess(false);
  };

  // Submit contract
  const handleSubmitContract = (e) => {
    e?.preventDefault();
    setContractSuccess(true);
    setShowContract(false);
    setTimeout(() => showMainMenu(), 2000);
    alert("Contract submitted successfully!");
  };

  // Submit feedback
  const handleSubmitFeedback = (e) => {
    e.preventDefault();
    const form = e.target;
    const orderId = form.orderId.value.trim();
    const rating = form.rating.value;
    const accuracy = form.accuracy.value;
    const timeliness = form.timeliness.value;

    if (!orderId || !rating || !accuracy || !timeliness) {
      alert("Please fill in all required fields.");
      return;
    }

    setFeedbackSuccess(true);
    form.reset();

    setTimeout(() => showMainMenu(), 2000);
  };

  const isMainMenuVisible = !showContract && !showFeedback;

  // Render main menu cards
  const renderMainMenu = () => (
    <>
      <h1 className="head" id="serviceHeader">
        Welcome to our service! Which one would you like to do?
      </h1>

      <section className="Container" id="serviceSection">
        {/* Add Orders */}
        <div className="food-card">
          <img src={foodImage} alt="Food Order" />
          <Link to="/service2">
            <button type="button" id="addOrdersButton">
              ADD ORDERS
            </button>
          </Link>
        </div>

        {/* Add Contract */}
        <div className="food-card">
          <img src={contractImage} alt="Contract Payment" />
          <button id="addContratButton" onClick={() => setShowContract(true)}>
            ADD CONTRACT
          </button>
        </div>

        {/* Give Feedback */}
        <div className="food-card">
          <img src={feedbackImage} alt="Feedback" />
          <button id="giveFeedbackButton" onClick={() => setShowFeedback(true)}>
            GIVE Feedback
          </button>
        </div>
      </section>

      {/* Contract Success Message */}
      {contractSuccess && (
        <div className="success-message visible-message">
          Contract submitted successfully!
        </div>
      )}

      {/* Feedback Success Message */}
      {feedbackSuccess && (
        <div className="success-message visible-message">
          Feedback submitted successfully!
        </div>
      )}
    </>
  );

  return (
    <div className="service-page-wrapper">
      {/* Main Menu */}
      {isMainMenuVisible && renderMainMenu()}

      {/* Contract Form Overlay */}
      {showContract && (
        <div className="contrat-form-overlay visible">
          <form className="contrat-form" onSubmit={handleSubmitContract}>
            <h2>Contract Form</h2>

            {/* Full Name */}
            <label htmlFor="firstName">First Name</label>
            <input type="text" id="firstName" name="firstName" required />

            <label htmlFor="lastName">Last Name</label>
            <input type="text" id="lastName" name="lastName" required />

            {/* ID Number */}
            <label htmlFor="idNumber">ID Number</label>
            <input type="text" id="idNumber" name="idNumber" required />

            {/* Phone */}
            <label htmlFor="phone">Phone Number (Ethiopia)</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              pattern="^(\+251|0)[1-9][0-9]{8}$"
              placeholder="e.g. +251912345678 or 0912345678"
              required
            />

            {/* Amount */}
            <label htmlFor="contractAmount">Contract Amount (ETB)</label>
            <input type="number" id="contractAmount" name="contractAmount" required />

            <div className="button-group">
              <button type="submit">Submit Contract</button>
              <button type="button" onClick={showMainMenu}>
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Feedback Form Overlay */}
      {showFeedback && (
        <section className="feedback-section visible">
          <form id="feedbackForm" onSubmit={handleSubmitFeedback}>
            <h2>Delivery Feedback</h2>
            <label htmlFor="orderId">Order ID</label>
            <input type="text" id="orderId" name="orderId" />
            <label htmlFor="rating">Rate the Delivery</label>
            <select id="rating" name="rating">
              <option value="">Select Rating</option>
              <option value="1">1, Very Satisfied</option>
              <option value="2">2, Satisfied</option>
              <option value="3">3, Not Satisfied</option>
            </select>
            <label htmlFor="accuracy">Was your order correct?</label>
            <select id="accuracy" name="accuracy">
              <option value="">Select</option>
              <option value="yes">Yes</option>
              <option value="no">No</option>
            </select>
            <label htmlFor="timeliness">Was the delivery on time?</label>
            <select id="timeliness" name="timeliness">
              <option value="">Select</option>
              <option value="yes">Yes</option>
              <option value="no">No</option>
            </select>
            <label htmlFor="comment">Additional Comments</label>
            <textarea id="comment" name="comment" rows="4"></textarea>
            <button type="submit">Submit Feedback</button>
            <button type="button" onClick={showMainMenu}>
              Back to Menu
            </button>
          </form>
        </section>
      )}
    </div>
  );
};

export default Service;
