import React, { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import "./OrderPage.css";

// Import food images
import riceImg from "../../assets/images/Rice.jpg";
import beyeImg from "../../assets/images/Aynet food.webp";
import pastaImg from "../../assets/images/pasta - Copy.jpg";
import chechebsaImg from "../../assets/images/chechebsa.jpg";
import softDrinkImg from "../../assets/images/leslase be hayland - Copy.webp";
import tastyImg from "../../assets/images/tasty with yellow.jpg";
import shiroImg from "../../assets/images/shrowet - Copy.jpg";
import enkulalImg from "../../assets/images/enkulal firfr.jpg";
import misrFreshImg from "../../assets/images/misr be alcha - Copy.webp";
import misrKeyImg from "../../assets/images/misr be alcha.webp";
import dinichAlchaImg from "../../assets/images/dinch be alcha.jpg";
import firfrKeyImg from "../../assets/images/firfr be key.webp";
import dinichKeyImg from "../../assets/images/dinch be key.jpg";

const ALL_PRODUCTS = [
  { id: 1, title: "Rice", price: 100, url: riceImg },
  { id: 2, title: "Beyaynet", price: 60, url: beyeImg },
  { id: 3, title: "Pasta", price: 50, url: pastaImg },
  { id: 4, title: "Chechebsa", price: 50, url: chechebsaImg },
  { id: 5, title: "Soft Drink", price: 60, url: softDrinkImg },
  { id: 6, title: "Tasty", price: 70, url: tastyImg },
  { id: 7, title: "Shiro", price: 60, url: shiroImg },
  { id: 8, title: "Enkulal", price: 100, url: enkulalImg },
  { id: 9, title: "Misr Fresh", price: 70, url: misrFreshImg },
  { id: 10, title: "Misr Be Key", price: 70, url: misrKeyImg },
  { id: 11, title: "Dinich Be Alcha", price: 60, url: dinichAlchaImg },
  { id: 12, title: "Firfr Be Key", price: 60, url: firfrKeyImg },
  { id: 13, title: "Dinich Be Key", price: 50, url: dinichKeyImg },
];

const INITIAL_PRODUCT_COUNT = 3;

const OrderPage = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [productsToShow, setProductsToShow] = useState(
    ALL_PRODUCTS.slice(0, INITIAL_PRODUCT_COUNT)
  );
  const [cart, setCart] = useState(() => {
    const storedCart = localStorage.getItem("cart");
    return storedCart ? JSON.parse(storedCart) : [];
  });

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  const handleAddToOrder = useCallback((product) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.id === product.id);
      if (existing) {
        return prevCart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prevCart, { ...product, quantity: 1 }];
      }
    });
  }, []);

  const handleShowMore = () => setProductsToShow(ALL_PRODUCTS);

  const handleOrder = () => {
    if (cart.length === 0) return alert("Cart is empty!");
    const totalAmount = cart.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
    if (window.confirm(`Total: ${totalAmount} ETB. Confirm order?`)) {
      setCart([]);
      alert("Order placed successfully!");
    }
  };

  const MenuCard = ({ product }) => {
    const [added, setAdded] = useState(false);
    const handleClick = () => {
      handleAddToOrder(product);
      setAdded(true);
      setTimeout(() => setAdded(false), 1000);
    };
    return (
      <div className="card">
        <img src={product.url} alt={product.title} />
        <h5>{product.title}</h5>
        <h5 className="price">{product.price} ETB</h5>
        <button className={added ? "added" : ""} onClick={handleClick}>
          {added ? "Added!" : "ADD TO ORDER"}
        </button>
      </div>
    );
  };

  return (
    <div className="order-page-wrapper">
      {/* Sidebar */}
      <div className={`nav-div ${isSidebarOpen ? "nav-expanded" : ""}`}>
        <ul className="nav-list">
          <h1 className="cancle" onClick={() => setIsSidebarOpen(false)}>
            X
          </h1>
          <li>
            <Link to="/">HOME</Link>
          </li>
          <li>
            <Link to="/service">SERVICE</Link>
          </li>
          <li>
            <Link to="/aboutus">ABOUT US</Link>
          </li>
          <li>
            <Link to="/login">LOGIN</Link>
          </li>
          <li>
            <Link to="/contactus">CONTACT US</Link>
          </li>
        </ul>
      </div>

      {/* Top navbar */}
      <div className="navbar">
        <div className="menu" onClick={() => setIsSidebarOpen(true)}>
          <div />
          <div />
          <div />
        </div>
        <div className="cart__btn">
          <button className="cart" onClick={handleOrder}>
            Order
          </button>
          <button className="count">{totalItems}</button>
        </div>
      </div>

      {/* Menu cards */}
      <div className="container">
        <h1 className="our--menu">Menu List</h1>
        <div className="card--container">
          {productsToShow.map((p) => (
            <MenuCard key={p.id} product={p} />
          ))}
        </div>
        {productsToShow.length < ALL_PRODUCTS.length && (
          <button className="more" onClick={handleShowMore}>
            MORE ---&gt;
          </button>
        )}
      </div>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <div>
            <h4>About Us</h4>
            <p>Favorite food destination since 2023.</p>
          </div>
          <div>
            <h4>Contact</h4>
            <p>Email: order@food.com</p>
            <p>Phone: +251 966140343</p>
          </div>
          <div>
            <h4>Follow Us</h4>
            <p>Facebook</p>
            <p>Instagram</p>
            <p>Telegram</p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2023 FoodWeb. All rights reserved</p>
        </div>
      </footer>
    </div>
  );
};

export default OrderPage;
