import React, { useState } from "react";
import "./ContactUs.css";

const ContactUs = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    location: "",
    message: "",
    comments: false,
  });

  const [errors, setErrors] = useState({});

  const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const validateEthiopianPhone = (phone) => {
    const cleaned = phone.replace(/[^\d+]/g, "");
    const patterns = [
      /^09\d{8}$/, /^07\d{8}$/,
      /^2519\d{8}$/, /^2517\d{8}$/,
      /^\+2519\d{8}$/, /^\+2517\d{8}$/
    ];
    return patterns.some((pattern) => pattern.test(cleaned));
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let newErrors = {};

    if (!validateEmail(formData.email)) {
      newErrors.email = "Please enter a valid email address";
    }

    if (formData.phone && !validateEthiopianPhone(formData.phone)) {
      newErrors.phone = "Please enter a valid Ethiopian phone number";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    alert("Your message has been submitted successfully!");
    setFormData({
      name: "",
      email: "",
      phone: "",
      location: "",
      message: "",
      comments: false,
    });
    setErrors({});
  };

  return (
    <div className="contact-container">
      <div className="contact-header">
        <h1>Contact Us</h1>
        <p>Have questions about our dining services? We'd love to hear from you.</p>
      </div>

      <div className="contact-content">
        <div className="form-section">
          <form onSubmit={handleSubmit}>
            <label htmlFor="name">Full Name</label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder="Your full name"
              value={formData.name}
              onChange={handleChange}
              required
            />

            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="Your email address"
              value={formData.email}
              onChange={handleChange}
              required
              className={errors.email ? "error-border" : ""}
            />
            {errors.email && <div className="error-message active">{errors.email}</div>}

            <label htmlFor="phone">
              Phone <span className="phone-examples">(e.g. 0912345678, +251912345678)</span>
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              placeholder="Your Ethiopian phone number"
              value={formData.phone}
              onChange={handleChange}
              className={errors.phone ? "error-border" : ""}
            />
            {errors.phone && <div className="error-message active">{errors.phone}</div>}

            <label htmlFor="location">Location</label>
            <input
              type="text"
              id="location"
              name="location"
              placeholder="City, Region"
              value={formData.location}
              onChange={handleChange}
            />

            <label htmlFor="message">Message</label>
            <textarea
              id="message"
              name="message"
              placeholder={
                formData.comments
                  ? "Type your message here"
                  : "Please check the box above to enable"
              }
              value={formData.message}
              onChange={handleChange}
              disabled={!formData.comments}
            />

            <div className="instruction">
              <strong>Note:</strong> Please check the box below to enable the message field.
            </div>

            <label className="checkbox-label">
              <input
                type="checkbox"
                id="comments"
                name="comments"
                checked={formData.comments}
                onChange={handleChange}
              />
              Questions or Comments?
            </label>

            <button type="submit">Submit</button>
          </form>
        </div>

        <div className="info-section">
          <img
            src="https://img.freepik.com/premium-photo/thoughtful-woman-is-talking-mobile-phone_447912-6750.jpg?semt=ais_hybrid&w=740"
            alt="Contact Person"
            className="contact-img"
          />
          <h3>Get in Touch</h3>
          <p><strong>Email:</strong> dining@dbu.edu.et</p>
          <p><strong>Phone:</strong> +251 01 681 5440</p>
          <p><strong>Address:</strong> Debre Birhan University, Debre Birhan, Amhara, Ethiopia</p>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
