import React from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom"; // Import useLocation

import Navbar from "./Components/Navbar";
import Footer from "./Components/Footer";

import Home from "./pages/Home/Home";
import AboutUs from "./pages/AboutUs/AboutUs";
import Service from "./pages/Service/Service";
import Login from "./pages/Login/Login";
import ContactUs from "./pages/ContactUs/ContactUs";
import AdminDashboard from "./pages/AdminDashboard/AdminDashboard";
import UserDashboard from "./pages/AdminDashboard/UserDashboard";
import OrderPage from "./pages/Service/OrderPage";
import Register from "./pages/Register/Register";

// Create a new component that handles the conditional rendering
// This component must be rendered *inside* the <Router>
function AppContent() {
  const location = useLocation();

  // Define the paths where the Navbar should NOT be displayed
  const hideNavbarPaths = [
    "/service2",
    // Add any other paths here where you want to hide the Navbar
    // e.g., "/login", "/register", "/admindashboard" if they should also be nav-less
  ];

  // Check if the current path is in the hide list
  const shouldHideNavbar = hideNavbarPaths.includes(location.pathname);

  return (
    <>
      {/* Conditionally render the Navbar */}
      {!shouldHideNavbar && <Navbar />}

      <main style={{ minHeight: '85vh', padding: '20px' }}>
         <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/aboutus" element={<AboutUs />} />
            <Route path="/service" element={<Service />} />
            <Route path="/service2" element={<OrderPage />} /> {/* This page will have no Navbar */}
            <Route path="/login" element={<Login />} />
            <Route path="/contactus" element={<ContactUs />} />
            <Route path="/admindashboard" element={<AdminDashboard />} />        
            <Route path="/register" element={<Register />} />
            <Route path="/UserDashboard" element={<UserDashboard />} />

            {/* <Route path="*" element={<h1>404 - Page Not Found</h1>} /> */}
         </Routes>
      </main>
      
      <Footer />
    </>
  );
}


function App() {
  return (
    <Router>
      <AppContent /> {/* Render the AppContent component inside the Router */}
    </Router>
  );
}

export default App;
