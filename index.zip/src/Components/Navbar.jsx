import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom"; 
import "./Navbar.css";
// NOTE: You'll need to install react-icons if you want to use the food icon:
// import { BiSolidFoodMenu } from 'react-icons/bi'; 

const Navbar = () => {
    const [open, setOpen] = useState(false);
    const [scrolled, setScrolled] = useState(false);
    const [user, setUser] = useState(null); 
    const navigate = useNavigate();

    const closeMenu = () => setOpen(false);

    // --- Authentication Check ---
    useEffect(() => {
        const currentUser = JSON.parse(sessionStorage.getItem("currentUser"));
        setUser(currentUser);
    }, [navigate]);

    // --- Scroll Effect (Mimics HTML Scroll Listener) ---
    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    // --- Conditional Display Variables ---
    const isLoggedIn = !!user;
    const isAdmin = user && user.role === 'admin';
    const isCustomer = user && user.role === 'customer';

    const handleLogout = () => {
        sessionStorage.removeItem("currentUser");
        setUser(null); 
        closeMenu();
        navigate("/login"); 
    };

    return (
        <header>
            {/* The class structure matches the HTML's nav-container and scroll effect */}
            <div className={`nav-container ${scrolled ? 'scrolled' : ''}`} id="mainNavBar">
                
                {/* LOGO: Uses the Bootstrap icon (bi-egg-fried) */}
                <Link to="/" className="logo-link" onClick={closeMenu}>
                    <div className="logo">
                        <i className="bi bi-egg-fried"></i> DBU LAUNCH
                    </div>
                </Link>

                <div className="mobile-menu-container">
                    {/* Hamburger Menu Button */}
                    <button className="mobile-menu-btn" id="menuBtn" onClick={() => setOpen(!open)}>
                        <i className="bi bi-list"></i>
                    </button>
                    
                    {/* Navigation Links: Uses 'active' class for mobile toggle */}
                    <nav id="mainNav" className={open ? "active" : ""}>
                        
                        {/* Always Visible Links */}
                        <Link to="/" onClick={closeMenu}>HOME</Link>
                        <Link to="/aboutus" onClick={closeMenu}>ABOUT</Link>
                        <Link to="/service" onClick={closeMenu}>SERVICE</Link>
                        <Link to="/contactus" onClick={closeMenu}>CONTACT</Link>

                        {/* Role-Based Links */}
                        {isCustomer && (
                            <Link to="/UserDashboard" onClick={closeMenu}>MY DASHBOARD</Link>
                        )}
                        
                        {isAdmin && (
                            <Link to="/admindashboard" onClick={closeMenu}>ADMIN PANEL</Link>
                        )}

                        {/* Login / Logout */}
                        {!isLoggedIn ? (
                            <Link to="/login" onClick={closeMenu}>LOGIN</Link>
                        ) : (
                            // Using a button for logout to handle the action
                            <button onClick={handleLogout} className="nav-logout-btn">
                                LOGOUT ({user.username})
                            </button>
                        )}

                    </nav>
                </div>
            </div>
        </header>
    );
};
 
export default Navbar;